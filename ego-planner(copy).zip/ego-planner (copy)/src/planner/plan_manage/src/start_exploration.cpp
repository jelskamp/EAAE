#include <ros/ros.h>
#include <std_msgs/Bool.h>

int main(int argc, char** argv) {
    ros::init(argc, argv, "start_exploration");
    ros::NodeHandle nh;

    ros::Publisher waypoint_reached_pub = nh.advertise<std_msgs::Bool>("/waypoint_reached", 10);

    ros::Duration(1.0).sleep();  // Ensure the ROS topic is initialized
    std_msgs::Bool msg;
    msg.data = true;

    ROS_WARN("Publishing initial /waypoint_reached = true... Starting exploration!");
    waypoint_reached_pub.publish(msg);

    ros::Duration(1.0).sleep();  // Give time to ensure the message is sent
    return 0;
}
